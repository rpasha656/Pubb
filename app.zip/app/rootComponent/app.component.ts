import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app/rootComponent/app.component.html',
  styleUrls:['app/rootComponent/app.component.css']
})
export class AppComponent { 
  constructor() {}
  display;
clickHandler(){
	this.display = true;
}
}