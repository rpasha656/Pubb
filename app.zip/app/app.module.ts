import { NgModule }      from '@angular/core';
import { BrowserModule, Title } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import {DialogModule} from 'primeng/primeng';
//import { Router } from '@angular/router';

import { HttpModule } from '@angular/http';
import { AppComponent } from './rootComponent/app.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpModule,DialogModule ],
  declarations: [ AppComponent],
  providers:    [ Title],
  bootstrap:    [ AppComponent ]
})

export class AppModule { 

  /*constructor(public router: Router) {
    if( window.localStorage.getItem("userLoggedIn") == "true")
      router.navigate(['home']);
  }*/
}



